===========
curlwrapper
===========

Towel Stuff provides such and such and so and so. You might find
it most useful for tasks involving <x> and also <y>. Typical usage
often looks like this::

    #!/usr/bin/env python

    from curlwrapper.browser import *


(Note the double-colon and 4-space indent formatting above.)

Paragraphs are separated by blank lines. *Italics*, **bold**,
and ``monospace`` look like this.


Installation
=========

(sudo) easy_install CurlWrapper

A Sub-Section
-------------

Numbered lists look like you'd expect:

1. hi there

2. must be going

Urls are http://like.this and links can be
written `like this <http://www.example.com/foo/bar>`_.
A Browser library for Python!

Features:
  + Curl Support
  + Cookies

Documentation: 
Mailing list: 
Chat: IRC freenode.net #
      Web interface: 
Wiki: 
Bug tracker: 

Souce code: 
    Library: 
    Examples: 

Author: Ben Holloway
License: MIT
Dependencies:
    Python 2.6 or newer


===Resources===
http://msdn.microsoft.com/en-us/library/system.net.httpwebresponse.aspx
